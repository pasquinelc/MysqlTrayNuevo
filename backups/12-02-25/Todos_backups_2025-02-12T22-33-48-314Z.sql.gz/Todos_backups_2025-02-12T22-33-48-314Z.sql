-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: turbinux.com    Database: backups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backup_configs`
--

DROP TABLE IF EXISTS `backup_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `host` text NOT NULL,
  `port` int NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `databases` json NOT NULL,
  `schedule` text NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `retention` int DEFAULT '30',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_configs`
--

LOCK TABLES `backup_configs` WRITE;
/*!40000 ALTER TABLE `backup_configs` DISABLE KEYS */;
INSERT INTO `backup_configs` VALUES (2,'Todos','turbinux.com',3349,'root2','pacman','[\"backups\", \"depo_clientes_excel\"]','0 12 * * *',1,30);
/*!40000 ALTER TABLE `backup_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_id` int NOT NULL,
  `database` text NOT NULL,
  `start_time` timestamp NOT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `status` text NOT NULL,
  `file_size` int DEFAULT NULL,
  `file_path` text,
  `error` text,
  `metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
INSERT INTO `backup_logs` VALUES (1,1,'terpel','2025-02-12 00:24:24','2025-02-12 00:24:48','failed',0,NULL,'stdout maxBuffer length exceeded','{\"error\": \"RangeError [ERR_CHILD_PROCESS_STDIO_MAXBUFFER]: stdout maxBuffer length exceeded\\n    at Socket.onChildStdout (node:child_process:490:14)\\n    at Socket.emit (node:events:518:28)\\n    at addChunk (node:internal/streams/readable:561:12)\\n    at readableAddChunkPushByteMode (node:internal/streams/readable:512:3)\\n    at Readable.push (node:internal/streams/readable:392:5)\\n    at Pipe.onStreamRead (node:internal/stream_base_commons:191:23)\"}'),(2,1,'terpel','2025-02-12 00:32:48','2025-02-12 00:35:05','completed',442368,'backups/Terpelbackup_2025-02-11T18-32-47-679Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(3,1,'terpel','2025-02-12 02:33:22','2025-02-12 02:35:39','completed',451799,'backups/Terpelbackup_2025-02-11T20-33-21-573Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(4,1,'terpel','2025-02-12 02:48:38','2025-02-12 02:50:54','completed',442368,'backups/Terpelbackup_2025-02-11T20-48-37-819Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(5,1,'','2025-02-12 02:50:54','2025-02-12 02:50:54','failed',0,NULL,'WebSocket is not defined','{\"error\": \"ReferenceError: WebSocket is not defined\\n    at <anonymous> (/home/runner/workspace/server/routes.ts:24:33)\\n    at Set.forEach (<anonymous>)\\n    at broadcast (/home/runner/workspace/server/routes.ts:23:17)\\n    at <anonymous> (/home/runner/workspace/server/routes.ts:75:7)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\"}'),(6,1,'terpel','2025-02-12 02:53:06','2025-02-12 02:55:23','completed',442368,'backups/Terpelbackup_2025-02-11T20-53-05-887Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(7,1,'terpel','2025-02-12 03:00:25','2025-02-12 03:02:41','completed',434411,'backups/Terpelbackup_2025-02-11T21-00-24-603Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(8,1,'terpel','2025-02-12 03:23:59','2025-02-12 03:26:18','completed',442368,'backups/Terpelbackup_2025-02-11T21-23-58-864Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(9,1,'terpel','2025-02-12 03:46:13','2025-02-12 03:48:34','completed',434411,'backups/Terpelbackup_2025-02-11T21-46-12-815Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(10,1,'terpel','2025-02-12 05:03:59','2025-02-12 05:06:21','completed',442368,'backups/Terpelbackup_2025-02-11T23-03-59-178Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(11,1,'terpel','2025-02-12 05:16:04','2025-02-12 05:18:22','completed',442368,'backups/Terpelbackup_2025-02-11T23-16-03-616Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(12,1,'terpel','2025-02-12 05:33:57','2025-02-12 05:36:16','completed',451800,'backups/Terpelbackup_2025-02-11T23-33-57-463Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(13,1,'terpel','2025-02-12 05:36:04','2025-02-12 05:38:19','completed',434411,'backups/Terpelbackup_2025-02-11T23-36-03-542Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(14,2,'depo_clientes_excel','2025-02-12 05:52:54','2025-02-12 05:53:03','completed',10,'backups/Todos_depo_clientes_excel_2025-02-11T23-52-53-708Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(15,2,'backups','2025-02-12 05:52:54','2025-02-12 05:52:59','completed',3150,'backups/Todos_backups_2025-02-11T23-52-53-708Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(16,1,'terpel','2025-02-12 06:00:00','2025-02-12 06:02:15','completed',442368,'backups/Terpelbackup_terpel_2025-02-12T00-00-00-010Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(17,2,'backups','2025-02-12 06:49:45','2025-02-12 06:49:50','completed',3843,'backups/Todos_backups_2025-02-12T00-49-45-241Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(18,2,'depo_clientes_excel','2025-02-12 06:49:45','2025-02-12 06:49:55','completed',1986,'backups/Todos_depo_clientes_excel_2025-02-12T00-49-45-241Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(19,2,'backups','2025-02-13 04:24:02','2025-02-13 04:24:07','completed',4137,'backups/Todos_backups_2025-02-12T22-24-01-890Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(20,2,'depo_clientes_excel','2025-02-13 04:24:02','2025-02-13 04:24:11','completed',1986,'backups/Todos_depo_clientes_excel_2025-02-12T22-24-01-890Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}');
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` text NOT NULL,
  `level` text NOT NULL,
  `message` text NOT NULL,
  `metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES (1,'2025-02-11 22:07:02','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-11T22:07:13.545Z\\\"}\"'),(2,'2025-02-11 23:04:01','backup','info','Iniciando respaldo para Terpelbackup','\"{\\\"config\\\":{\\\"name\\\":\\\"Terpelbackup\\\",\\\"databases\\\":[\\\"terpel\\\"],\\\"host\\\":\\\"turbinux.com\\\"}}\"'),(3,'2025-02-11 23:04:02','backup','info','Prueba de conexión MySQL exitosa',NULL),(4,'2025-02-11 23:06:22','backup','info','Respaldo completado exitosamente','\"{\\\"fileSize\\\":442368,\\\"path\\\":\\\"backups/Terpelbackup_2025-02-11T23-03-59-178Z.sql.gz\\\"}\"'),(5,'2025-02-11 23:12:17','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-11T23:12:12.818Z\\\"}\"'),(6,'2025-02-11 23:16:05','backup','info','Iniciando respaldo para Terpelbackup','\"{\\\"config\\\":{\\\"name\\\":\\\"Terpelbackup\\\",\\\"databases\\\":[\\\"terpel\\\"],\\\"host\\\":\\\"turbinux.com\\\"}}\"'),(7,'2025-02-11 23:16:06','backup','info','Prueba de conexión MySQL exitosa',NULL),(8,'2025-02-11 23:18:23','backup','info','Respaldo completado exitosamente','\"{\\\"fileSize\\\":442368,\\\"path\\\":\\\"backups/Terpelbackup_2025-02-11T23-16-03-616Z.sql.gz\\\"}\"'),(9,'2025-02-11 23:18:23','email','info','Preparando notificación de respaldo por correo para Terpelbackup',NULL),(10,'2025-02-11 23:18:23','email','error','Faltan variables de entorno requeridas: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS',NULL),(11,'2025-02-11 23:18:23','email','error','Error al enviar notificación de respaldo','\"{\\\"message\\\":\\\"Faltan variables de entorno requeridas: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS\\\",\\\"stack\\\":\\\"Error: Faltan variables de entorno requeridas: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS\\\\n    at validateEmailConfig (/home/runner/workspace/server/backup/email.ts:50:11)\\\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\\\n    at async sendBackupNotification (/home/runner/workspace/server/backup/email.ts:58:5)\\\\n    at async performBackup (/home/runner/workspace/server/backup/mysql.ts:151:9)\\\\n    at async <anonymous> (/home/runner/workspace/server/routes.ts:70:19)\\\"}\"'),(12,'2025-02-11 23:18:23','backup','error','Error al enviar notificación de respaldo exitoso','\"{\\\"error\\\":\\\"Faltan variables de entorno requeridas: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS\\\",\\\"stack\\\":\\\"Error: Faltan variables de entorno requeridas: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS\\\\n    at validateEmailConfig (/home/runner/workspace/server/backup/email.ts:50:11)\\\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\\\n    at async sendBackupNotification (/home/runner/workspace/server/backup/email.ts:58:5)\\\\n    at async performBackup (/home/runner/workspace/server/backup/mysql.ts:151:9)\\\\n    at async <anonymous> (/home/runner/workspace/server/routes.ts:70:19)\\\"}\"'),(13,'2025-02-11 23:33:17','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-11T23:33:12.334Z\\\"}\"'),(14,'2025-02-11 23:33:59','backup','info','Iniciando respaldo para Terpelbackup','\"{\\\"config\\\":{\\\"name\\\":\\\"Terpelbackup\\\",\\\"databases\\\":[\\\"terpel\\\"],\\\"host\\\":\\\"turbinux.com\\\"}}\"'),(15,'2025-02-11 23:34:00','backup','info','Prueba de conexión MySQL exitosa',NULL),(16,'2025-02-11 23:36:05','backup','info','Iniciando respaldo para Terpelbackup','\"{\\\"config\\\":{\\\"name\\\":\\\"Terpelbackup\\\",\\\"databases\\\":[\\\"terpel\\\"],\\\"host\\\":\\\"turbinux.com\\\"}}\"'),(17,'2025-02-11 23:36:06','backup','info','Prueba de conexión MySQL exitosa',NULL),(18,'2025-02-11 23:36:06','backup','warning','Advertencia de mysqldump','\"{\\\"message\\\":\\\"mysqldump: \\\"}\"'),(19,'2025-02-11 23:36:06','backup','warning','Advertencia de mysqldump','\"{\\\"message\\\":\\\"\\\\n\\\"}\"'),(20,'2025-02-11 23:36:17','backup','info','Respaldo completado exitosamente','\"{\\\"fileSize\\\":451800,\\\"path\\\":\\\"backups/Terpelbackup_2025-02-11T23-33-57-463Z.sql.gz\\\"}\"'),(21,'2025-02-11 23:36:17','email','info','Preparando notificación de respaldo por correo para Terpelbackup',NULL),(22,'2025-02-11 23:36:18','email','info','Enviando notificación por correo a: pcc2100@yahoo.com',NULL),(23,'2025-02-11 23:36:18','email','info','Intentando enviar email con configuración SMTP','\"{\\\"host\\\":\\\"smtp.gmail.com\\\",\\\"port\\\":\\\"465\\\",\\\"user\\\":\\\"facturacion@turbinux.com\\\",\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"secure\\\":true}\"'),(24,'2025-02-11 23:36:19','email','info','Email enviado exitosamente','\"{\\\"messageId\\\":\\\"<dc0b6a73-5ea7-87f0-8e4a-b798aa58cf55@turbinux.com>\\\",\\\"response\\\":\\\"250 2.0.0 OK  1739316977 e9e14a558f8ab-3d14dbe776csm20091795ab.70 - gsmtp\\\",\\\"envelope\\\":{\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"to\\\":[\\\"pcc2100@yahoo.com\\\"]}}\"'),(25,'2025-02-11 23:36:19','email','info','Notificación de respaldo enviada exitosamente',NULL),(26,'2025-02-11 23:38:20','backup','info','Respaldo completado exitosamente','\"{\\\"fileSize\\\":434411,\\\"path\\\":\\\"backups/Terpelbackup_2025-02-11T23-36-03-542Z.sql.gz\\\"}\"'),(27,'2025-02-11 23:38:20','email','info','Preparando notificación de respaldo por correo para Terpelbackup',NULL),(28,'2025-02-11 23:38:21','email','info','Enviando notificación por correo a: pcc2100@yahoo.com',NULL),(29,'2025-02-11 23:38:21','email','info','Intentando enviar email con configuración SMTP','\"{\\\"host\\\":\\\"smtp.gmail.com\\\",\\\"port\\\":\\\"465\\\",\\\"user\\\":\\\"facturacion@turbinux.com\\\",\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"secure\\\":true}\"'),(30,'2025-02-11 23:38:21','email','info','Email enviado exitosamente','\"{\\\"messageId\\\":\\\"<1dee8cba-bf41-b307-d03c-fa3adef75219@turbinux.com>\\\",\\\"response\\\":\\\"250 2.0.0 OK  1739317099 e9e14a558f8ab-3d1584d7e24sm16623535ab.24 - gsmtp\\\",\\\"envelope\\\":{\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"to\\\":[\\\"pcc2100@yahoo.com\\\"]}}\"'),(31,'2025-02-11 23:38:22','email','info','Notificación de respaldo enviada exitosamente',NULL),(32,'2025-02-11 23:46:36','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-11T23:46:33.417Z\\\"}\"'),(33,'2025-02-11 23:52:55','backup','info','Iniciando respaldo para Todos','\"{\\\"config\\\":{\\\"name\\\":\\\"Todos\\\",\\\"databases\\\":[\\\"backups\\\",\\\"depo_clientes_excel\\\"],\\\"host\\\":\\\"turbinux.com\\\"}}\"'),(34,'2025-02-11 23:52:56','backup','info','Prueba de conexión MySQL exitosa',NULL),(35,'2025-02-11 23:53:00','backup','info','Respaldo completado exitosamente para backups','\"{\\\"fileSize\\\":3150,\\\"path\\\":\\\"backups/Todos_backups_2025-02-11T23-52-53-708Z.sql.gz\\\"}\"'),(36,'2025-02-11 23:53:05','backup','info','Respaldo completado exitosamente para depo_clientes_excel','\"{\\\"fileSize\\\":10,\\\"path\\\":\\\"backups/Todos_depo_clientes_excel_2025-02-11T23-52-53-708Z.sql.gz\\\"}\"'),(37,'2025-02-11 23:53:05','email','info','Preparando notificación de respaldo por correo para Todos',NULL),(38,'2025-02-11 23:53:05','email','info','Enviando notificación por correo a: pcc2100@yahoo.com',NULL),(39,'2025-02-11 23:53:05','email','info','Intentando enviar email con configuración SMTP','\"{\\\"host\\\":\\\"smtp.gmail.com\\\",\\\"port\\\":\\\"465\\\",\\\"user\\\":\\\"facturacion@turbinux.com\\\",\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"secure\\\":true}\"'),(40,'2025-02-11 23:53:06','email','info','Email enviado exitosamente','\"{\\\"messageId\\\":\\\"<b439c117-8e8c-b37d-49af-b35b4af53eca@turbinux.com>\\\",\\\"response\\\":\\\"250 2.0.0 OK  1739317983 e9e14a558f8ab-3d1798017d7sm2552775ab.68 - gsmtp\\\",\\\"envelope\\\":{\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"to\\\":[\\\"pcc2100@yahoo.com\\\"]}}\"'),(41,'2025-02-11 23:53:06','email','info','Notificación de respaldo enviada exitosamente',NULL),(42,'2025-02-11 23:58:46','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-11T23:58:43.011Z\\\"}\"'),(43,'2025-02-11 23:59:02','email','info','Preparando reporte diario de respaldos...',NULL),(44,'2025-02-11 23:59:02','email','info','Enviando reporte diario a: pcc2100@yahoo.com',NULL),(45,'2025-02-11 23:59:02','email','info','Intentando enviar email con configuración SMTP','\"{\\\"host\\\":\\\"smtp.gmail.com\\\",\\\"port\\\":\\\"465\\\",\\\"user\\\":\\\"facturacion@turbinux.com\\\",\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"secure\\\":true}\"'),(46,'2025-02-11 23:59:03','email','info','Email enviado exitosamente','\"{\\\"messageId\\\":\\\"<b93ac209-02d2-f50a-c470-c9d0b19650e5@turbinux.com>\\\",\\\"response\\\":\\\"250 2.0.0 OK  1739318341 8926c6da1cb9f-4eccfa02797sm2979034173.57 - gsmtp\\\",\\\"envelope\\\":{\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"to\\\":[\\\"pcc2100@yahoo.com\\\"]}}\"'),(47,'2025-02-11 23:59:03','email','info','Reporte diario enviado exitosamente',NULL),(48,'2025-02-12 00:00:02','backup','info','Iniciando respaldo para Terpelbackup','\"{\\\"config\\\":{\\\"name\\\":\\\"Terpelbackup\\\",\\\"databases\\\":[\\\"terpel\\\"],\\\"host\\\":\\\"turbinux.com\\\"}}\"'),(49,'2025-02-12 00:00:02','backup','info','Prueba de conexión MySQL exitosa',NULL),(50,'2025-02-12 00:02:17','backup','info','Respaldo completado exitosamente para terpel','\"{\\\"fileSize\\\":442368,\\\"path\\\":\\\"backups/Terpelbackup_terpel_2025-02-12T00-00-00-010Z.sql.gz\\\"}\"'),(51,'2025-02-12 00:02:17','email','info','Preparando notificación de respaldo por correo para Terpelbackup',NULL),(52,'2025-02-12 00:02:17','email','info','Enviando notificación por correo a: pcc2100@yahoo.com',NULL),(53,'2025-02-12 00:02:17','email','info','Intentando enviar email con configuración SMTP','\"{\\\"host\\\":\\\"smtp.gmail.com\\\",\\\"port\\\":\\\"465\\\",\\\"user\\\":\\\"facturacion@turbinux.com\\\",\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"secure\\\":true}\"'),(54,'2025-02-12 00:02:18','email','info','Email enviado exitosamente','\"{\\\"messageId\\\":\\\"<ceb3ba56-ea6f-8c99-a3ca-19b4d139ac3e@turbinux.com>\\\",\\\"response\\\":\\\"250 2.0.0 OK  1739318536 8926c6da1cb9f-4ecec84b881sm1868121173.85 - gsmtp\\\",\\\"envelope\\\":{\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"to\\\":[\\\"pcc2100@yahoo.com\\\"]}}\"'),(55,'2025-02-12 00:02:18','email','info','Notificación de respaldo enviada exitosamente',NULL),(56,'2025-02-12 00:02:18','email','info','Preparando notificación de respaldo por correo para Terpelbackup',NULL),(57,'2025-02-12 00:02:18','email','error','Error al enviar notificación de respaldo','\"{\\\"message\\\":\\\"logs.filter is not a function\\\",\\\"stack\\\":\\\"TypeError: logs.filter is not a function\\\\n    at sendBackupNotification (/home/runner/workspace/server/backup/email.ts:60:29)\\\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\\\\n    at async Job.job (/home/runner/workspace/server/backup/scheduler.ts:39:7)\\\"}\"'),(58,'2025-02-12 00:05:19','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-12T00:05:15.977Z\\\"}\"'),(59,'2025-02-12 00:26:05','system','info','Configuración de respaldo eliminada: Terpelbackup','\"{\\\"configId\\\":1,\\\"name\\\":\\\"Terpelbackup\\\"}\"'),(60,'2025-02-12 00:27:30','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-12T00:27:27.284Z\\\"}\"'),(61,'2025-02-12 00:49:47','backup','info','Iniciando respaldo para Todos','\"{\\\"config\\\":{\\\"name\\\":\\\"Todos\\\",\\\"databases\\\":[\\\"backups\\\",\\\"depo_clientes_excel\\\"],\\\"host\\\":\\\"turbinux.com\\\"}}\"'),(62,'2025-02-12 00:49:47','backup','info','Prueba de conexión MySQL exitosa',NULL),(63,'2025-02-12 00:49:52','backup','info','Respaldo completado exitosamente para backups','\"{\\\"fileSize\\\":3843,\\\"path\\\":\\\"backups/Todos_backups_2025-02-12T00-49-45-241Z.sql.gz\\\"}\"'),(64,'2025-02-12 00:49:56','backup','info','Respaldo completado exitosamente para depo_clientes_excel','\"{\\\"fileSize\\\":1986,\\\"path\\\":\\\"backups/Todos_depo_clientes_excel_2025-02-12T00-49-45-241Z.sql.gz\\\"}\"'),(65,'2025-02-12 00:49:56','email','info','Preparando notificación de respaldo por correo para Todos',NULL),(66,'2025-02-12 00:49:56','email','info','Enviando notificación por correo a: pcc2100@yahoo.com',NULL),(67,'2025-02-12 00:49:56','email','info','Intentando enviar email con configuración SMTP','\"{\\\"host\\\":\\\"smtp.gmail.com\\\",\\\"port\\\":\\\"465\\\",\\\"user\\\":\\\"facturacion@turbinux.com\\\",\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"secure\\\":true}\"'),(68,'2025-02-12 00:49:57','email','info','Email enviado exitosamente','\"{\\\"messageId\\\":\\\"<fef32700-5b08-3b82-64a0-a6ef7268632e@turbinux.com>\\\",\\\"response\\\":\\\"250 2.0.0 OK  1739321395 8926c6da1cb9f-4ecdfa2f1ccsm2364211173.88 - gsmtp\\\",\\\"envelope\\\":{\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"to\\\":[\\\"pcc2100@yahoo.com\\\"]}}\"'),(69,'2025-02-12 00:49:58','email','info','Notificación de respaldo enviada exitosamente',NULL),(70,'2025-02-12 00:52:38','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-12T00:52:35.085Z\\\"}\"'),(71,'2025-02-12 00:57:21','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-12T00:57:18.394Z\\\"}\"'),(72,'2025-02-12 22:18:51','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-12T22:18:52.339Z\\\"}\"'),(73,'2025-02-12 22:21:36','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-12T22:21:38.999Z\\\"}\"'),(74,'2025-02-12 22:22:47','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-12T22:22:49.595Z\\\"}\"'),(75,'2025-02-12 22:23:59','backup','info','Iniciando respaldo para Todos','\"{\\\"config\\\":{\\\"name\\\":\\\"Todos\\\",\\\"databases\\\":[\\\"backups\\\",\\\"depo_clientes_excel\\\"],\\\"host\\\":\\\"turbinux.com\\\"}}\"'),(76,'2025-02-12 22:24:00','backup','info','Prueba de conexión MySQL exitosa',NULL),(77,'2025-02-12 22:24:04','backup','info','Respaldo completado exitosamente para backups','\"{\\\"fileSize\\\":4137,\\\"path\\\":\\\"backups/Todos_backups_2025-02-12T22-24-01-890Z.sql.gz\\\"}\"'),(78,'2025-02-12 22:24:08','backup','info','Respaldo completado exitosamente para depo_clientes_excel','\"{\\\"fileSize\\\":1986,\\\"path\\\":\\\"backups/Todos_depo_clientes_excel_2025-02-12T22-24-01-890Z.sql.gz\\\"}\"'),(79,'2025-02-12 22:24:08','email','info','Preparando notificación de respaldo por correo para Todos',NULL),(80,'2025-02-12 22:24:08','email','info','Enviando notificación por correo a: pcc2100@yahoo.com',NULL),(81,'2025-02-12 22:24:08','email','info','Intentando enviar email con configuración SMTP','\"{\\\"host\\\":\\\"smtp.gmail.com\\\",\\\"port\\\":\\\"465\\\",\\\"user\\\":\\\"facturacion@turbinux.com\\\",\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"secure\\\":true}\"'),(82,'2025-02-12 22:24:09','email','info','Email enviado exitosamente','\"{\\\"messageId\\\":\\\"<0895d862-cc30-4cab-26ed-cd96cba8857c@turbinux.com>\\\",\\\"response\\\":\\\"250 2.0.0 OK  1739399052 8926c6da1cb9f-4ed28149500sm15841173.2 - gsmtp\\\",\\\"envelope\\\":{\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"to\\\":[\\\"pcc2100@yahoo.com\\\"]}}\"'),(83,'2025-02-12 22:24:09','email','info','Notificación de respaldo enviada exitosamente',NULL),(84,'2025-02-12 22:33:07','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-12T22:33:09.479Z\\\"}\"'),(85,'2025-02-12 22:33:45','backup','info','Iniciando respaldo para Todos','\"{\\\"config\\\":{\\\"name\\\":\\\"Todos\\\",\\\"databases\\\":[\\\"backups\\\",\\\"depo_clientes_excel\\\"],\\\"host\\\":\\\"turbinux.com\\\",\\\"backupDir\\\":\\\"backups/12-02-25\\\"}}\"'),(86,'2025-02-12 22:33:46','backup','info','Prueba de conexión MySQL exitosa',NULL);
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'backups'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-12 22:33:53
