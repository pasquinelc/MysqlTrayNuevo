-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: turbinux.com    Database: depo_clientes_excel
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id_cliente` varchar(36) NOT NULL,
  `curp` varchar(20) DEFAULT NULL,
  `domicilio` json DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `limite_credito` double DEFAULT NULL,
  `nombre` varchar(200) NOT NULL,
  `observaciones` varchar(1080) DEFAULT NULL,
  `primer_apellido` varchar(100) DEFAULT NULL,
  `rfc` varchar(20) NOT NULL,
  `segundo_apellido` varchar(100) DEFAULT NULL,
  `telefono` json DEFAULT NULL,
  `tipo_persona` smallint NOT NULL,
  `id_estatus_cliente` int NOT NULL,
  `id_regimen_fiscal` int NOT NULL,
  `info_sap` json DEFAULT NULL,
  `id_sucursal` varchar(255) NOT NULL,
  `id_dias_credito` varchar(20) NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes_depo`
--

DROP TABLE IF EXISTS `clientes_depo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes_depo` (
  `﻿IDCLIENTE` int DEFAULT NULL,
  `NOMBRE1` text,
  `NOMBRE2` text,
  `Nombre_adicional` text,
  `NOMBRE_PARTICULAR` text,
  `Nombre_adicional_PARTICULAR` text,
  `NOMBRE_MORAL` text,
  `Nombre_adicional_MORAL` text,
  `RFC` text,
  `Contar_RFC` int DEFAULT NULL,
  `Cliente_particular` text,
  `x_0` text,
  `TELEFONO` text,
  `EMAIL` text,
  `FAX` text,
  `LIMITEDECREDITO` int DEFAULT NULL,
  `APATERNO` text,
  `AMATERNO` text,
  `APELLIDO` text,
  `OBSERVACIONES` text,
  `NUMEXTERIOR` text,
  `Inf_adic_del_num` text,
  `Inf_adicional_del_numero_exterior` text,
  `NUMINTERIOR` text,
  `CALLE` text,
  `IDCODIGOPOSTAL_X` text,
  `DESCRIPCION` text,
  `SUCURSAL_MAS_CERCANA` text,
  `XX_SIGLAS` text,
  `MUNICIPIO` text,
  `ESTADO` text,
  `IDCODIGOPOSTAL` text,
  `x_SIGLAS` text,
  `DIASDECREDITO` text,
  `CIUDAD` text,
  `REGIMENFISCAL` text,
  `CLAVESAT` int DEFAULT NULL,
  `ESTATUSCLIENTE` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes_depo`
--

LOCK TABLES `clientes_depo` WRITE;
/*!40000 ALTER TABLE `clientes_depo` DISABLE KEYS */;
/*!40000 ALTER TABLE `clientes_depo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regimen_fiscal`
--

DROP TABLE IF EXISTS `regimen_fiscal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `regimen_fiscal` (
  `id_regimen_fiscal` int NOT NULL AUTO_INCREMENT,
  `clave_sat` int NOT NULL,
  `regimen_fiscal` varchar(255) NOT NULL,
  PRIMARY KEY (`id_regimen_fiscal`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regimen_fiscal`
--

LOCK TABLES `regimen_fiscal` WRITE;
/*!40000 ALTER TABLE `regimen_fiscal` DISABLE KEYS */;
INSERT INTO `regimen_fiscal` VALUES (2,601,'General de Ley Personas Morales'),(3,626,'Régimen Simplificado de Confianza'),(4,621,'Incorporación Fiscal'),(5,612,'Personas Físicas con Actividades Empresariales y Profesionales'),(6,605,'Sueldos y Salarios e Ingresos Asimilados a Salarios'),(8,622,'Actividades Agrícolas, Ganaderas, Silvícolas y Pesqueras'),(9,606,'Arrendamiento'),(10,616,'Sin obligaciones fiscales'),(11,625,'Régimen de las Actividades Empresariales con ingresos a través de Plataformas Tecnológicas'),(12,603,'Personas Morales con Fines no Lucrativos'),(13,608,'Demás ingresos'),(14,610,'Residentes en el Extranjero sin Establecimiento Permanente en México'),(15,611,'Ingresos por Dividendos (socios y accionistas)'),(16,614,'Ingresos por intereses'),(17,615,'Régimen de los ingresos por obtención de premios'),(18,620,'Sociedades Cooperativas de Producción que optan por diferir sus ingresos'),(19,623,'Opcional para Grupos de Sociedades'),(20,624,'Coordinados');
/*!40000 ALTER TABLE `regimen_fiscal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sepomex`
--

DROP TABLE IF EXISTS `sepomex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sepomex` (
  `d_codigo` text,
  `d_asenta` text,
  `d_tipoasenta` text,
  `d_mnpio` text,
  `d_estado` text,
  `d_ciudad` text,
  `d_cp` text,
  `c_estado` text,
  `c_oficina` text,
  `c_cp` text,
  `c_tipoasenta` text,
  `c_mnpio` text,
  `id_asentacpcons` text,
  `d_zona` text,
  `c_cve_ciudad` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sepomex`
--

LOCK TABLES `sepomex` WRITE;
/*!40000 ALTER TABLE `sepomex` DISABLE KEYS */;
/*!40000 ALTER TABLE `sepomex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'depo_clientes_excel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-13 20:28:33
