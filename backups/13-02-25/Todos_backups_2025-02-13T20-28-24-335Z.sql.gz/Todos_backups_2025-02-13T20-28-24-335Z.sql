-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: turbinux.com    Database: backups
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backup_configs`
--

DROP TABLE IF EXISTS `backup_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `host` text NOT NULL,
  `port` int NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `databases` json NOT NULL,
  `schedule` text NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `retention` int DEFAULT '30',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_configs`
--

LOCK TABLES `backup_configs` WRITE;
/*!40000 ALTER TABLE `backup_configs` DISABLE KEYS */;
INSERT INTO `backup_configs` VALUES (2,'Todos','turbinux.com',3349,'root2','pacman','[\"backups\", \"depo_clientes_excel\"]','0 12 * * *',1,30);
/*!40000 ALTER TABLE `backup_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_id` int NOT NULL,
  `database` text NOT NULL,
  `start_time` timestamp NOT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `status` text NOT NULL,
  `file_size` int DEFAULT NULL,
  `file_path` text,
  `error` text,
  `metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
INSERT INTO `backup_logs` VALUES (1,2,'backups','2025-02-13 04:55:13','2025-02-13 04:55:18','completed',1326,'backups/12-02-25/Todos_backups_2025-02-12T22-55-13-183Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}'),(2,2,'depo_clientes_excel','2025-02-13 04:55:13','2025-02-13 04:55:22','completed',1986,'backups/12-02-25/Todos_depo_clientes_excel_2025-02-12T22-55-13-183Z.sql.gz',NULL,'{\"warnings\": \"mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}');
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` text NOT NULL,
  `level` text NOT NULL,
  `message` text NOT NULL,
  `metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES (1,'2025-02-12 22:55:10','backup','info','Iniciando respaldo para Todos','\"{\\\"config\\\":{\\\"name\\\":\\\"Todos\\\",\\\"databases\\\":[\\\"backups\\\",\\\"depo_clientes_excel\\\"],\\\"host\\\":\\\"turbinux.com\\\",\\\"backupDir\\\":\\\"backups/12-02-25\\\"}}\"'),(2,'2025-02-12 22:55:11','backup','info','Prueba de conexión MySQL exitosa',NULL),(3,'2025-02-12 22:55:15','backup','info','Respaldo completado exitosamente para backups','\"{\\\"fileSize\\\":1326,\\\"path\\\":\\\"backups/12-02-25/Todos_backups_2025-02-12T22-55-13-183Z.sql.gz\\\"}\"'),(4,'2025-02-12 22:55:19','backup','info','Respaldo completado exitosamente para depo_clientes_excel','\"{\\\"fileSize\\\":1986,\\\"path\\\":\\\"backups/12-02-25/Todos_depo_clientes_excel_2025-02-12T22-55-13-183Z.sql.gz\\\"}\"'),(5,'2025-02-12 22:55:19','email','info','Preparando notificación de respaldo por correo para Todos',NULL),(6,'2025-02-12 22:55:20','email','info','Enviando notificación por correo a: pcc2100@yahoo.com',NULL),(7,'2025-02-12 22:55:20','email','info','Intentando enviar email con configuración SMTP','\"{\\\"host\\\":\\\"smtp.gmail.com\\\",\\\"port\\\":\\\"465\\\",\\\"user\\\":\\\"facturacion@turbinux.com\\\",\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"secure\\\":true}\"'),(8,'2025-02-12 22:55:20','email','info','Email enviado exitosamente','\"{\\\"messageId\\\":\\\"<3973f63d-b614-b432-dc56-22920908bc6d@turbinux.com>\\\",\\\"response\\\":\\\"250 2.0.0 OK  1739400923 ca18e2360f4ac-85566f68f96sm1882139f.32 - gsmtp\\\",\\\"envelope\\\":{\\\"from\\\":\\\"facturacion@turbinux.com\\\",\\\"to\\\":[\\\"pcc2100@yahoo.com\\\"]}}\"'),(9,'2025-02-12 22:55:21','email','info','Notificación de respaldo enviada exitosamente',NULL),(10,'2025-02-13 20:27:37','system','info','Servidor iniciado correctamente','\"{\\\"time\\\":\\\"2025-02-13T20:27:42.397Z\\\"}\"'),(11,'2025-02-13 20:28:17','backup','info','Iniciando respaldo para Todos','\"{\\\"config\\\":{\\\"name\\\":\\\"Todos\\\",\\\"databases\\\":[\\\"backups\\\",\\\"depo_clientes_excel\\\"],\\\"host\\\":\\\"turbinux.com\\\",\\\"backupDir\\\":\\\"backups/13-02-25\\\"}}\"'),(12,'2025-02-13 20:28:18','backup','info','Prueba de conexión MySQL exitosa',NULL);
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'backups'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-13 20:28:29
